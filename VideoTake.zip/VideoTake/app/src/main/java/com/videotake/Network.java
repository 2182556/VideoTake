package com.videotake;

import android.net.Uri;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class Network {
    private static final String TAG_NAME = Network.class.getSimpleName();
    private static final String MEALS_BASE_URL =  "https://shareameal-api.herokuapp.com/api/meal";

    public static String getMeal(String mealID){
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String mealJSONString = null;

        try {
            Log.d(TAG_NAME,"Starting API retrieval");
            Uri builtURI = Uri.parse(MEALS_BASE_URL).buildUpon()
                    .appendPath(mealID)
                    .build();

            URL requestURL = new URL(builtURI.toString());
            Log.d(TAG_NAME,"Url for GET Request: " + builtURI.toString());

            urlConnection = (HttpURLConnection) requestURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            InputStream inputStream = urlConnection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder builder = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
                builder.append("\n");
            }

            if (builder.length() == 0) {
                return null;
            }
            mealJSONString = builder.toString();
        } catch (IOException e) {
            Log.e(TAG_NAME,e.getMessage());
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    Log.e(TAG_NAME,e.getMessage());
                }
            }
        }
        Log.d(TAG_NAME, "Result: " + mealJSONString);
        return mealJSONString;
    }

    public static void trial() {
        try{
            URL obj = new URL("https://api.themoviedb.org/3/authentication/token/validate_with_login?api_key=5144de6e9e1919536a34c7c1e2736453");

            HttpURLConnection httpURLConnection = (HttpURLConnection) obj.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Content-Type", "application/json");

            Log.d(TAG_NAME,"url construction");
            // For POST only - START
            httpURLConnection.setDoOutput(true);
            OutputStream os = httpURLConnection.getOutputStream();
            String POST_PARAMS = "{ \"username\":\"ExampleUser  \", \"password\":\"anexample-1 \", \"request_token\": \"12e6795f2420ab44e93607e6748240929a10ae3b\" }";
            os.write(POST_PARAMS.getBytes());
            os.flush();
            os.close();
            // For POST only - END

            Log.d(TAG_NAME,"why");

            int responseCode = httpURLConnection.getResponseCode();
            Log.d(TAG_NAME,"POST Response Code :: " + responseCode);

            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // print result
                Log.d(TAG_NAME,response.toString());
            } else {
                Log.e(TAG_NAME,"POST request not worked");
            }
        } catch (Exception e) {
            Log.e(TAG_NAME,"oh no" + e.getMessage());
        }

    }

//    public static void alsoATrial(){
//        HttpClient httpclient = HttpClients.createDefault();
//        HttpPost httppost = new HttpPost("https://api.themoviedb.org/3/authentication/session/new?api_key=5144de6e9e1919536a34c7c1e2736453");
//
//// Request parameters and other properties.
////        List<NameValuePair> params = new ArrayList<NameValuePair>(2);
////        params.add(new BasicNameValuePair("param-1", "12345"));
////        params.add(new BasicNameValuePair("param-2", "Hello!"));
////        httppost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
//
////Execute and get the response.
//        HttpResponse response = httpclient.execute(httppost);
//        HttpEntity entity = response.getEntity();
//
//        if (entity != null) {
//            try (InputStream instream = entity.getContent()) {
//                // do something useful
//            }
//        }
//    }

}
